import React, { useState } from "react";
import data from "./data/ap-tourist-data.json";

export default function App() {
  const [selectedCity, setSelectedCity] = useState(null);

  const handleCityChange = (e) => {
    const cityName = e.target.value;
    const cityData = data.find((c) => c.city === cityName);
    setSelectedCity(cityData);
  };

  const openDirections = (lat, lng) => {
    window.open(`https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`, "_blank");
  };

  return (
    <div className="min-h-screen p-6 bg-gradient-to-b from-blue-100 to-white text-gray-800">
      <h1 className="text-3xl font-bold text-center mb-4">Tourist Spots in Andhra Pradesh</h1>
      <div className="flex justify-center mb-6">
        <select onChange={handleCityChange} className="p-2 rounded border border-gray-300">
          <option value="">-- Select a City --</option>
          {data.map((city) => (
            <option key={city.city} value={city.city}>{city.city}</option>
          ))}
        </select>
      </div>

      {selectedCity && (
        <div>
          <h2 className="text-xl font-semibold mb-4 text-center">{selectedCity.city}</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {selectedCity.places.map((place, index) => (
              <div key={index} className="bg-white shadow rounded-xl p-4">
                <img src={place.image} alt={place.name} className="w-full h-48 object-cover rounded-md mb-2" />
                <h3 className="text-lg font-bold">{place.name}</h3>
                <p className="text-sm text-gray-600 mb-2">{place.description}</p>
                <button
                  onClick={() => openDirections(place.latitude, place.longitude)}
                  className="bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600"
                >
                  Get Directions
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}